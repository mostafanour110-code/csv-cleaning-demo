"""Synthetic CSV cleaning demo, Python standard library only."""
from pathlib import Path
import csv,json,argparse,re
from decimal import Decimal,InvalidOperation

def clean(source,destination):
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 accepted=[];rejected=[];seen=set()
 with open(source,encoding='utf-8-sig',newline='') as f:
  reader=csv.DictReader(f)
  if reader.fieldnames!=['code','name','amount']:raise ValueError('Expected exactly: code,name,amount')
  for line,row in enumerate(reader,2):
   if None in row or any(v is None for v in row.values()):
    rejected.append({'line':line,'code':'','name':'','amount':'','reason':'column_count'});continue
   row={k:v.strip() for k,v in row.items()};errors=[]
   if not re.fullmatch(r'[A-Z][A-Z0-9-]{0,19}',row['code']):errors.append('invalid_code')
   if not row['name']:errors.append('name_required')
   if len(row['name'])>100:errors.append('name_too_long')
   try:
    a=Decimal(row['amount'])
    if not a.is_finite() or a<0 or a>Decimal('1000000') or a.as_tuple().exponent < -2:errors.append('invalid_amount')
   except InvalidOperation:errors.append('invalid_amount')
   if row['code'] in seen:errors.append('duplicate_code_after_first')
   if errors:rejected.append({'line':line,**row,'reason':';'.join(errors)})
   else:
    seen.add(row['code']);row['amount']=format(a,'.2f');accepted.append(row)
 def export(name,fields,rows):
  with (destination/name).open('w',encoding='utf-8-sig',newline='') as f:
   w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 export('accepted.csv',['code','name','amount'],accepted)
 export('rejected.csv',['line','code','name','amount','reason'],rejected)
 result={'input_rows':len(accepted)+len(rejected),'accepted_rows':len(accepted),'rejected_rows':len(rejected),'total_amount':str(sum((Decimal(x['amount']) for x in accepted),Decimal('0')).quantize(Decimal('.01')))}
 (destination/'summary.json').write_text(json.dumps(result,indent=2))
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--out',default='output');a=p.parse_args();print(json.dumps(clean(a.input,a.out),indent=2))
